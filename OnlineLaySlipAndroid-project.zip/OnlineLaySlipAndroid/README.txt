ONLINE LAY SLIP ENTRY - ANDROID PROJECT

This project wraps the supplied Onlinelayslipv2.html in an Android WebView.
The original lay calculations and UI are retained. Browser localStorage is
enabled so slips remain stored in this app's WebView data on this phone.

PDF and Excel export:
The HTML export function has a small Android-specific bridge. In the Android
app, exported PDF and XLSX files are saved to the device Downloads folder.

BUILD ON WINDOWS / MAC / LINUX
1. Install Android Studio.
2. Open this folder (OnlineLaySlip) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer app-debug.apk to the Android phone and install it.

BUILD REQUIREMENTS
- Android Studio with Android SDK Platform 35
- JDK 17 (Android Studio's bundled JDK is suitable)
- Internet for the first Gradle sync (to download Gradle and Android plugins)

NOTES
- App ID: com.garment.layslip
- Minimum Android: Android 6.0 (API 23)
- Google Fonts are loaded from the supplied HTML stylesheet when internet is
  available; system font fallbacks are included in the HTML.
- The app itself and the lay calculations run locally. The original HTML
  stores slips in localStorage; this is app-local storage, not cloud sync.
- Test PDF/Excel export and backup/restore with sample data before production.

BUILD USING ONLY YOUR PHONE (CLOUD BUILD)
1. Extract this ZIP on your phone.
2. Create a GitHub repository in your browser.
3. Upload all files and folders from this project, including the hidden
   .github/workflows/build-apk.yml file. Keep the folder structure.
4. In the repository, open Actions.
5. Select "Build Android APK" and tap "Run workflow" (or push to main).
6. When the workflow finishes, open its run and download the
   "OnlineLaySlip-debug-apk" artifact.
7. Extract the downloaded artifact ZIP; install app-debug.apk.

The cloud build requires a GitHub account and internet access. The APK is
unsigned for Play Store release, but suitable for personal testing/install.
